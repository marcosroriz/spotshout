package org.apache.ws.jaxme.js;


/** This instance specifies an Java source object, which
 * has a type.
 */
public interface TypedValue {
	/** Returns the objects type.
	 */
	public JavaQName getType();
}
